define("Form1", function() {
    return function(controller) {
        function addWidgetsForm1() {
            this.setDefaultUnit(kony.flex.DP);
            var PaddedButtonRound = new kony.ui.FlexContainer({
                "centerY": "75%",
                "clipBounds": true,
                "height": "45dp",
                "id": "PaddedButtonRound",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            PaddedButtonRound.setDefaultUnit(kony.flex.DP);
            var ButtonRound = new kony.ui.Button({
                "bottom": "5dp",
                "focusSkin": "ButtonSkinActive",
                "id": "ButtonRound",
                "isVisible": true,
                "left": "10dp",
                "onClick": controller.AS_Button_c2a3a1eef3744e4f86f967d5b7dcec46,
                "right": "10dp",
                "skin": "ButtonSkinNormal",
                "text": "Start Scan",
                "top": "5dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            PaddedButtonRound.add(ButtonRound);
            var txtBarCode = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "height": "50dp",
                "id": "txtBarCode",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_CHAT,
                "left": "16dp",
                "secureTextEntry": false,
                "skin": "TXTBARCODE",
                "text": "Here is the code you scanned",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "174dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoFilter": false,
                "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
                "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
            });
            var lblBarCode = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "8%",
                "id": "lblBarCode",
                "isVisible": true,
                "left": "92dp",
                "skin": "LBLBARCODE",
                "text": "Label",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "367dp",
                "width": "90%",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var flxPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "skin": "FLXPOPUP",
                "top": "0%",
                "width": "100%",
                "zIndex": 10
            }, {}, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var flxInstallBarcode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "35%",
                "id": "flxInstallBarcode",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2dp",
                "skin": "FLXPOPUPROUND",
                "top": "238dp",
                "width": "90%",
                "zIndex": 1
            }, {}, {});
            flxInstallBarcode.setDefaultUnit(kony.flex.DP);
            var flxpopupTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "25%",
                "id": "flxpopupTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "skin": "FLX00A0DD",
                "top": "0%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxpopupTitle.setDefaultUnit(kony.flex.DP);
            var lblPopupTitle = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPopupTitle",
                "isVisible": true,
                "left": "4%",
                "skin": "LBLWHITE",
                "text": "Barcode Scanner",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            flxpopupTitle.add(lblPopupTitle);
            var lblPopupMessage = new kony.ui.Label({
                "id": "lblPopupMessage",
                "isVisible": true,
                "left": "4%",
                "skin": "LBLWHITE",
                "text": "Barcode Scanner needs to install zxing barcode scanner. you want to install app now ?",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "35%",
                "width": "92%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var flxPopupUserActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0%",
                "centerX": "50%",
                "clipBounds": true,
                "height": "25%",
                "id": "flxPopupUserActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxPopupUserActions.setDefaultUnit(kony.flex.DP);
            var btnPopupYes = new kony.ui.Button({
                "focusSkin": "ButtonPositiveSkinActive",
                "height": "100%",
                "id": "btnPopupYes",
                "isVisible": true,
                "onClick": controller.AS_Button_c607279a3bd6457481b5fee1194aa22c,
                "right": "0%",
                "skin": "BTNPOPUPYES",
                "text": "Yes",
                "top": "0%",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnPopupNo = new kony.ui.Button({
                "focusSkin": "slButtonGlossRed",
                "height": "100%",
                "id": "btnPopupNo",
                "isVisible": true,
                "left": "0%",
                "onClick": controller.AS_Button_ab4c740faeb648c7b0517732e3696419,
                "skin": "BTNPOPUPNO",
                "text": "No",
                "top": "0%",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPopupUserActions.add(btnPopupYes, btnPopupNo);
            flxInstallBarcode.add(flxpopupTitle, lblPopupMessage, flxPopupUserActions);
            flxPopup.add(flxInstallBarcode);
            var flxIosScannerHolder = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxIosScannerHolder",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "skin": "FLXPOPUPROUND",
                "top": "0%",
                "width": "100%",
                "zIndex": 10
            }, {}, {});
            flxIosScannerHolder.setDefaultUnit(kony.flex.DP);
            flxIosScannerHolder.add();
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 40
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var flxBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxBack",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "onClick": controller.AS_FlexContainer_f98feb9db512412e91007a367234946f,
                "skin": "slFbox",
                "top": "0%",
                "width": "15%",
                "zIndex": 1
            }, {}, {});
            flxBack.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "50%",
                "id": "imgBack",
                "isVisible": true,
                "skin": "slImage",
                "src": "backbtn_white.png",
                "width": "50%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBack.add(imgBack);
            var lblTitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTitle",
                "isVisible": true,
                "skin": "CopyslLabel0a8ad989826d041",
                "text": "Scanning bar code",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            flxTitle.add(flxBack, lblTitle);
            this.add(PaddedButtonRound, txtBarCode, lblBarCode, flxPopup, flxIosScannerHolder, flxTitle);
        };
        return [{
            "addWidgets": addWidgetsForm1,
            "enabledForIdleTimeout": false,
            "id": "Form1",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "pagingEnabled": false,
            "postShow": controller.AS_Form_ceacfa6d9d5349fe8b39bfdc617cc4e5,
            "skin": "FRMBG"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "footerOverlap": false,
            "headerOverlap": false,
            "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
            "retainScrollPosition": false,
            "titleBar": true,
            "titleBarSkin": "slTitleBar",
            "windowSoftInputMode": constants.FORM_ADJUST_PAN
        }]
    }
});